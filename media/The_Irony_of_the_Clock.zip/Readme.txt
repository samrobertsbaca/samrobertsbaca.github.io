The Irony of the Clock (11.28.2010)

game by Tipp
music by (evil/scoopex/garlick/coolphat) and Sergeisergeievich

arrow keys are deelicious



extracting is also deelicious