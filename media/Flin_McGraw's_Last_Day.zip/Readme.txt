Flin McGraw's Last Day
(by Tipp in 2010 for the gamemakergames "the list" compo)

Arrows Move
Enjoy!