The Arm (9.11.2010)

Game by Tipp
Music by John Marwin

WASD + Mouse



Extracting the game could prove very useful.