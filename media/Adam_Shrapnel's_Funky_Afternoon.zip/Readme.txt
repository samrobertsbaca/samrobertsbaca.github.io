Adam Shrapnel's Funky Afternoon
(by tipp 2010)

Arrow Keys Move
Enjoy!