Refus Q. Jibberjabber's Day Out
(by Tipp in 2010 for the tigsource "a game by it's cover" compo)

Arrows Move
Enjoy!